
package fr.iut;

import org.jgrapht.Graph;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jgrapht.Graphs;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.SimpleGraph;
import org.jgrapht.nio.AttributeType;
import org.jgrapht.nio.DefaultAttribute;
import org.jgrapht.nio.dot.DOTExporter;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

public class HollywoodGraphBuilder {

    static class Film {
        String title;
        List<String> cast;
    }

    public static Graph<String, DefaultEdge> creerGraphe(String cheminFichier) throws IOException {
        Graph<String, DefaultEdge> g = new SimpleGraph<>(DefaultEdge.class);
        BufferedReader f = new BufferedReader(new FileReader(cheminFichier));
        String ligne;
        Gson gson = new Gson();

        while ((ligne = f.readLine()) != null) {
            JsonElement filmJson = JsonParser.parseString(ligne);
            Film film = gson.fromJson(filmJson, Film.class);

            if (film.cast != null) {
                List<String> noms = new ArrayList<>();
                for (String a : film.cast) {
                    String nom = a.replaceAll("\\[\\[|\\]\\]", "");
                    if (nom.contains("|")) {
                        nom = nom.split("\\|")[0];
                    }
                    nom = nom.trim();
                    g.addVertex(nom);
                    noms.add(nom);
                }

                // relier tous les acteurs entre eux
                for (int i = 0; i < noms.size(); i++) {
                    for (int j = 0; j < noms.size(); j++) {
                        if (!noms.get(i).equals(noms.get(j))) {
                            g.addEdge(noms.get(i), noms.get(j));
                        }
                    }
                }
            }
        }
        f.close();
        return g;
    }

    // aider du TP1
    public static void exportGraph(Graph<String, DefaultEdge> graph, String chemin) throws IOException {
        DOTExporter<String, DefaultEdge> exporter = new DOTExporter<String, DefaultEdge>();
        exporter.setVertexAttributeProvider((x) -> Map.of("label", new DefaultAttribute<>(x, AttributeType.STRING)));
        exporter.exportGraph(graph, new FileWriter(chemin));
    }

    // 3.2
    public static Set<String> collaborateursCommuns(Graph<String, DefaultEdge> graphe, String acteur1, String acteur2) {
        Set<String> voisins1 = Graphs.neighborSetOf(graphe, acteur1);
        Set<String> voisins2 = Graphs.neighborSetOf(graphe, acteur2);

        Set<String> communs = new HashSet<>(voisins1);
        communs.retainAll(voisins2);
        return communs;
    }

    // 3.3
    /*
     * # SAE Exploration algorithmique d'un problème
     * 
     * Voici l'algorithme permettant d'obtenir l'ensemble des collaborateurs à
     * distance k d'un acteur ou d'une actrice. A vous de l'implémenter en JAVA
     * 
     * Algo collaborateurs_proches(G,u,k):
     * """Algorithme renvoyant l'ensemble des acteurs à distance au plus k de
     * l'acteur u dans le graphe G. La fonction renvoie None si u est absent du
     * graphe.
     * 
     * Parametres:
     * G: le graphe
     * u: le sommet de départ
     * k: la distance depuis u
     * """
     * si u n'est pas un sommet de G:
     * afficher u+"est un illustre inconnu"
     * fin de l'algorithme
     * collaborateurs = Ensemble vide
     * Ajouter u à l'ensemble des collaborateurs
     * pour tout i allant de 1 à k:
     * collaborateurs_directs = Ensemble Vide
     * Pour tout collaborateur c dans l'ensemble des collaborateurs
     * Pour tout voisin v de c:
     * si v n'est pas dans l'ensemble des collaborateurs:
     * Ajouter v à l'ensemble des collaborateurs_directs
     * Remplacer collaborateurs par l'union des collaborateurs et
     * collaborateurs_directs
     * Renvoyer l'ensemble collaborateurs
     * 
     * Vous pouvez par exemple utiliser la classe HashSet en java
     * (https://docs.oracle.com/javase/8/docs/api/java/util/HashSet.html) pour les
     * ensembles.
     */

    //

    public static Set<String> collaborateur_proches(Graph<String, DefaultEdge> G, String u, int k) {
        if (!G.containsVertex(u)) {
            System.out.println((u + " est un acteur inconnu"));
            return null;
        }

        Set<String> collaborateurs = new HashSet<>();
        collaborateurs.add(u);
        for (int i = 1; i <= k; i++) {
            Set<String> collaborateurs_directs = new HashSet<>();
            for (String collab : collaborateurs) {
                for (String voisin : Graphs.neighborSetOf(G, collab)) {
                    if (!collaborateurs.contains(voisin)) {
                        collaborateurs_directs.add(voisin);
                    }
                }
            }
            collaborateurs.addAll(collaborateurs_directs);
        }
        return collaborateurs;
    }

    public static int distanceEntreActeur(Graph<String, DefaultEdge> g, String acteurA, String acteurB) {
        if (!g.containsVertex(acteurA) || !g.containsVertex(acteurB)) {
            System.out.println("Un des deux acteur est inconnu");
            return -1;
        }

        Set<String> vue = new HashSet<>();
        Set<String> courant = new HashSet<>();
        courant.add(acteurA);
        vue.add(acteurA);

        int distance = 0;

        while (!courant.isEmpty()) {
            if (courant.contains(acteurB)) {
                return distance;
            }

            Set<String> suivant = new HashSet<>();
            for (String acteur : courant) {
                for (String voisin : Graphs.neighborListOf(g, acteur)) {
                    if (!vue.contains(voisin)) {
                        suivant.add(voisin);
                        vue.add(voisin);
                    }
                }
            }
            courant = suivant;
            distance++;
        }

        return -1;

    }

    // 3.4
    /**
     * Calcule la distance maximale de centralité à partir d'un sommet donné dans un
     * graphe.
     * 
     * Cette méthode effectue un parcours en largeur (BFS) à partir du sommet
     * parametre u dans le graphe G
     * et retourne la plus grande distance (en nombre d'arêtes) entre parametre u et
     * tout autre sommet accessible.
     * Si le sommet parametre u n'existe pas dans le graphe, la méthode affiche un
     * message d'erreur et retourne -1.
     * 
     *
     * @param G le graphe dans lequel effectuer le calcul (graphe non orienté de
     *          type {Graph<String, DefaultEdge>})
     * @param u le sommet de départ (acteur) pour le calcul de la centralité
     * @return la distance maximale atteignable depuis parametre u, ou -1 si
     *         parametre u n'est pas présent dans le graphe
     */
    public static int DistanceMaxCentralite(Graph<String, DefaultEdge> G, String u) {
      

        if (G == null || G.vertexSet().isEmpty()) { // Vérification si le graphe est vide
            System.out.println("Le graphe est vide ou nul"); // Message d'erreur si le graphe est vide
            return -1; // Si le graphe est vide, retourner -1
        }

        // Vérification si le sommet u existe dans le graphe G
        // Si u n'est pas un sommet du graphe, afficher un message d'erreur et retourner
        // -1
        if (!G.containsVertex(u)) {
            System.out.println(u + " est un acteur inconnu");
            return -1;
        }

        ArrayDeque<String> file = new ArrayDeque<>(); 

        // Map pour stocker les distances (équivalent au paramètre u.d du cours)
        Map<String, Integer> distances = new HashMap<>();

        // Initialisation BFS : la racine a une distance 0
        file.add(u);
        distances.put(u, 0);
        // distance maximale initiale
        int distanceMaximale = 0;

        // BFS classique du CM4
        while (!file.isEmpty()) {
            String sommetCourant = file.poll();
            int distanceActuelle = distances.get(sommetCourant);

            // Explorer tous les voisins du sommet courant
            for (String voisin : Graphs.neighborListOf(G, sommetCourant)) {
                // Si le voisin n'est pas encore visité
                if (!distances.containsKey(voisin)) {
                    // Calculer la nouvelle distance (u.p.d + 1 comme dans le cours)
                    int nouvelleDistance = distanceActuelle + 1;
                    distances.put(voisin, nouvelleDistance);

                    // Ajouter à la file pour exploration future
                    file.add(voisin);

                    // Mettre à jour la distance maximale trouvée
                    distanceMaximale = Math.max(distanceMaximale, nouvelleDistance);
                }
            }
        }

        return distanceMaximale;
    }

    /**
     * Trouve et retourne l'acteur (sommet) le plus central dans le graphe donné,
     * basé sur la centralité minimale.
     * La centralité est déterminée par la distance maximale entre l'acteur et tout
     * autre acteur du graphe.
     * L'acteur ayant la plus petite de ces distances maximales est considéré comme
     * le plus central.
     *
     * @param G le graphe représentant les acteurs et leurs connexions
     * @return le nom de l'acteur le plus central, ou null si le graphe est vide
     */
    public static String centre(Graph<String, DefaultEdge> G) {
        if (G.vertexSet().isEmpty()) {
            return null;
        }
        int minCentralite = Integer.MAX_VALUE;
        String acteurCentral = null;

        for (String acteur : G.vertexSet()) {
            int c = DistanceMaxCentralite(G, acteur);

            if (c >= 0 && c < minCentralite) {
                minCentralite = c;
                acteurCentral = acteur;
            }
        }

        return acteurCentral;
    }

    // 3.5
    /**
     * Calcule le diamètre du graphe, qui est défini comme la distance maximale
     * entre tous les couples d'acteurs.
     * 
     * Cette méthode parcourt tous les sommets du graphe et calcule la distance
     * maximale de centralité pour chacun d'eux.
     * Le diamètre est la plus grande de ces distances maximales.
     *
     * @param G le graphe dans lequel effectuer le calcul (graphe non orienté de type
     *          Graph<String, DefaultEdge>})
     * @return le diamètre du graphe, ou 0 si le graphe est vide
     */
    public static int diametreGraphe(Graph<String, DefaultEdge> G) {
        if (G.vertexSet().isEmpty()) {
            return 0;
        }
        int diametre = 0;
        for (String acteur : G.vertexSet()) {
            int excentricite = DistanceMaxCentralite(G, acteur);
            if (excentricite > diametre) {
                diametre = excentricite;
            }
        }
        return diametre;
    }

    // Bonus 3.6
    /**
     * Trouve l'acteur central d'un groupe d'acteurs dans le graphe donné.
     * L'acteur central est celui qui a la plus petite distance maximale par rapport
     * à tous les membres du groupe.
     *
     * @param G le graphe représentant les acteurs et leurs connexions
     * @param groupeEntreActeur l'ensemble des acteurs du groupe pour lequel on
     *                          cherche l'acteur central
     * @return le nom de l'acteur central du groupe, ou null si le groupe est vide
     */

    public static String centreDuGroupe(Graph<String, DefaultEdge> G, Set<String> groupeEntreActeur) {
        int minCentral = Integer.MAX_VALUE;
        String actCentral = null;
        for (String act : G.vertexSet()) {
            int centraliteAct = 0;
            for (String membreDuGroupe : groupeEntreActeur) {
                int distance = distanceEntreActeur(G, act, membreDuGroupe);
                if (distance == -1) {
                    centraliteAct = Integer.MAX_VALUE;
                    break;
                }
                centraliteAct = Math.max(centraliteAct, distance);
            }
            if (centraliteAct < minCentral) {
                minCentral = centraliteAct;
                actCentral = act;
            }
        }
        return actCentral;
    }

    /**
     * Génère un sous-graphe du graphe donné G, contenant le sommet u et tous les  
     * sommets
     * situés à une distance maximale k (collaborateurs) de u, ainsi que les arêtes
     * les reliant.
     *
     * @param G le graphe original à partir duquel extraire le sous-graphe         
     * @param u le sommet de départ pour le sous-graphe
     * @param k la distance maximale (nombre d'étapes) depuis u pour inclure les
     *          sommets
     * @return un nouveau sous-graphe contenant u, ses collaborateurs à distance au
     *         plus k, et les arêtes entre eux ;
     *         retourne null si u n'est pas présent dans G
     * 
     */
    public static Graph<String, DefaultEdge> sousGraph(Graph<String, DefaultEdge> G, String u, int k) {
        if (!G.containsVertex(u)) {
            return null;
        }
        Set<String> collab = collaborateur_proches(G, u, k);

        Graph<String, DefaultEdge> souGraph = new SimpleGraph<>(DefaultEdge.class);
        for (String act : collab) {
            souGraph.addVertex(act);
        }
        for (String act : collab) {
            for (String vois : Graphs.neighborSetOf(G, act)) {
                if (collab.contains(vois)) {
                    souGraph.addEdge(act, vois);
                }
            }
        }
        return souGraph;
    }

}