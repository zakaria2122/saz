package fr.iut;

import java.util.*;
import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultEdge;

public class Executable {
    public static void main(String[] args) {
        Graph<String, DefaultEdge> graphe = null;
        
        // 3.1 – Création et export du graphe
        try {
            graphe = HollywoodGraphBuilder.creerGraphe("data/data_100.txt");
            System.out.println("Nb acteurs: " + graphe.vertexSet().size());
            System.out.println("Nb liens: " + graphe.edgeSet().size());
            HollywoodGraphBuilder.exportGraph(graphe, "grapheGenerer/graph.dot");
            System.out.println("fichier DOT fait pour le graphe1.dot (Voir dossier grapheGenerer ! )");
        } catch (Exception e) {
            System.out.println("Erreur lors de la création du graphe : " + e.getMessage());
            return; // Si le graphe ne peut pas être créé, on arrête le programme
        }
        
        // 3.2 – Collaborateurs communs
        try {
            Set<String> communs = HollywoodGraphBuilder.collaborateursCommuns(graphe, "Tom Hanks", "Charles Durning");
            System.out.println("Collaborateurs communs entre Tom Hanks et Charles Durning:");
            if (communs.isEmpty()) {
                System.out.println("Aucun collaborateur commun trouvé.");
            } else {
                for (String nom : communs) {
                    System.out.println(" - " + nom);
                }
            }
        } catch (Exception e) {
            System.out.println("Erreur lors de la recherche de collaborateurs communs : " + e.getMessage());
        }
        
        // 3.3 – Collaborateurs à distance k
        try {
            System.out.println("----Collaborateur proche----");
            Set<String> proches = HollywoodGraphBuilder.collaborateur_proches(graphe, "Brad Pitt", 1);
            if (proches != null) {
                System.out.println("Collaborateurs proches de Brad Pitt en k=1 : ");
                for (String nom : proches) {
                    if (!nom.equals("Brad Pitt")) {
                        System.out.println(" - " + nom);
                    }
                }
            }
            
            // Affichage pour k=2
            Set<String> proches2 = HollywoodGraphBuilder.collaborateur_proches(graphe, "Brad Pitt", 2);
            System.out.println("Collaborateurs proches de Brad Pitt en k=2 : " + proches2);
            
            // Vérification de présence d'un acteur spécifique
            if (proches2 != null && proches2.contains("Tom Cruise")) {
                System.out.println("Oui, ils sont à distance 2 ou moins");
            } else {
                System.out.println("Non, ils ne sont pas à distance 2 ou moins...");
            }
        } catch (Exception e) {
            System.out.println("Erreur lors de la recherche de collaborateurs proches : " + e.getMessage());
        }
        
        // 3.3 bis – Distance exacte entre deux acteurs
        try {
            System.out.println("----Distance exacte entre 2 acteurs en int---- ");
            String acteur1 = "Nathan George";
            String acteur2 = "Jared Leto";
            int distance = HollywoodGraphBuilder.distanceEntreActeur(graphe, acteur1, acteur2);
            if (distance == -1) {
                System.out.println("il n'y a pas de lien entre " + acteur1 + " et " + acteur2);
            } else {
                System.out.println("la distance entre " + acteur1 + " et " + acteur2 + " est de " + distance);
            }
        } catch (Exception e) {
            System.out.println("Erreur lors du calcul de distance entre acteurs : " + e.getMessage());
        }
        
        // 3.4 – Centralité et centre
        try {
            System.out.println("----Centralité des acteurs---- ");
            int centralitePacino = HollywoodGraphBuilder.DistanceMaxCentralite(graphe, "Al Pacino");
            System.out.println("la centralité de Al Pacino : " + centralitePacino);
            
            String acteurCentral = HollywoodGraphBuilder.centre(graphe);
            System.out.println("Acteur central du graphe : " + acteurCentral);
        } catch (Exception e) {
            System.out.println("Erreur lors du calcul de centralité : " + e.getMessage());
        }
        
        // 3.5 – Distance maximale (diamètre)
        try {
            System.out.println("----Distance maximale (diamètre) du graphe----");
            int diam = HollywoodGraphBuilder.diametreGraphe(graphe);
            System.out.println("Diamètre du graphe : " + diam + " degrés");
            if (diam <= 6) {
                System.out.println("Oui, le diamètre est ≤ 6 !");
            } else {
                System.out.println("Non, le diamètre est > 6.");
            }
        } catch (Exception e) {
            System.out.println("Erreur lors du calcul du diamètre : " + e.getMessage());
        }
    
        // BONUS 3.6 – Centre d’un groupe
        try {
            System.out.println("---- Centre d'un groupe d'acteurs ----");
              Set<String> groupe = Set.of("Marlon Brando", "Robert De Niro", "Biff McGuire", "Kevin Bacon"); 
            String centreGroupe = HollywoodGraphBuilder.centreDuGroupe(graphe, groupe);
            System.out.println("Centre du groupe : " + centreGroupe);
        } catch (Exception e) {
            System.out.println("Erreur lors du calcul du centre du groupe : " + e.getMessage());
        }
    
        // BONUS 3.6 – Sous-graphe induit 
        try {
            System.out.println("------ Sous-graphe induit graphe 2 (Voir dossier grapheGenerer) ------");
            Graph<String, DefaultEdge> sousGraphe = HollywoodGraphBuilder.sousGraph(graphe, "Kevin Bacon", 1);
            if (sousGraphe != null) {
                HollywoodGraphBuilder.exportGraph(sousGraphe, "grapheGenerer/sous-graphe.dot"); // Exporter le sous-graphe
                System.out.println("Fichier DOT pour le sous-graphe.dot généré avec succès !");
            }
        } catch (Exception e) {
            System.out.println("Erreur lors de la création du sous-graphe : " + e.getMessage());
        }

        
    }

    
}
