package fr.iut;
import java.util.List;

public class Movie {
    String title;
    List<String> cast;
    List<String> directors;
    List<String> producers;
    List<String> companies;
    int year;
}