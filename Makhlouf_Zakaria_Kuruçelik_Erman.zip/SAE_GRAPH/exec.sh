#!/bin/bash

# Chemins des dossiers
SRC_DIR="src/main/java"
BIN_DIR="bin"
LIB_DIR="lib"

# Classe principale
MAIN_CLASS="fr.iut.Executable"

# Nettoyer ancien build
echo "Nettoyage du dossier de compilation..."
rm -rf "$BIN_DIR"

# Créer dossier de compilation
mkdir -p "$BIN_DIR"

# Compiler les sources avec le classpath des libs
echo "Compilation du projet..."
javac -cp "$LIB_DIR/*" -d "$BIN_DIR" $(find $SRC_DIR -name "*.java")

if [ $? -ne 0 ]; then
  echo "Erreur de compilation."
  exit 1
fi

# Lancer l'application avec le bon classpath
echo "Lancement de l'application..."
java -cp "$BIN_DIR:$LIB_DIR/*" "$MAIN_CLASS"

